---
description: 查看狀態
---

查看狀態

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `operations` 的 `status`：先確認 `requires`，再依序完成 `actions`；有 `checkpoint` 時停下等待使用者確認。
