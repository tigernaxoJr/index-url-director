---
description: 同步變更
---

同步變更

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `operations` 的 `sync`：先確認 `requires`，再依序完成 `actions`；有 `checkpoint` 時停下等待使用者確認。

做法見 product-video Skill 的 `workflow.md#sync`；未安裝 Skill 時讀取 https://aofa.tigernaxo.com/api/skills/product-video/workflow.md#sync
