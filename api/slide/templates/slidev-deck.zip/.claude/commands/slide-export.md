---
description: 匯出向量 PDF
---

匯出向量 PDF

依專案 `AGENTS.md` 的規則，執行 `schemas/workflow.json` 中 `steps` 的 `export`：調用 Slidev CLI 匯出高解析向量 PDF (output/slides.pdf)。
先用 `pnpm run state activity` 回報進度；有 `checkpoint` 時停下等待使用者確認，完成後以 `pnpm run state project --status` 更新狀態。

做法見 slidev-deck Skill 的 `export-guide.md`；未安裝 Skill 時讀取 https://aofa.tigernaxo.com/api/slide/skills/slidev-deck/export-guide.md
